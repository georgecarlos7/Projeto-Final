package br.com.senaibrasilia.projetofinal.test;

import java.math.BigDecimal;
import br.com.senaibrasilia.projetofinal.dao.CategoriaDAO;
import br.com.senaibrasilia.projetofinal.dao.ProdutoDAO;
import br.com.senaibrasilia.projetofinal.model.Categoria;
import br.com.senaibrasilia.projetofinal.model.Produto;

public class Principal {

	public static void main(String[] args) {
	        
		    Produto produto = new Produto();
	        ProdutoDAO produtoDAO = new ProdutoDAO();
	        Categoria categoria = new Categoria(null, null);
	        CategoriaDAO categoriaDAO = new CategoriaDAO(null);
	        
		    produto.setNome("Iphone");
	        produto.setDescri�ao("Nokia");
	        produto.setPre�o(new BigDecimal("5000"));
	        categoria.setNome("Marca");
	        produtoDAO.cadastrar(produto);
	        categoriaDAO.cadastrar(categoria);
	        
	        produto.setNome("Nokia C20 32GB");
	        produto.setDescri�ao("Android");
	        produto.setPre�o(new BigDecimal("1800"));
	        produtoDAO.atualizar(produto);
	        categoria.setNome("Nokia");
	        categoriaDAO.atualizar(categoria);
	        
	        produtoDAO.buscaPorId(produto.getID());    
	        produtoDAO.remover(categoria.getId());
	        
	        
	        
	        
	        
	        
	}
}