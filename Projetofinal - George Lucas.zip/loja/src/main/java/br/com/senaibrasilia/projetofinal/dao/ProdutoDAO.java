package br.com.senaibrasilia.projetofinal.dao;

import java.util.List;
import javax.persistence.EntityManager;
import com.mysql.cj.Query;
import br.com.senaibrasilia.projetofinal.model.Produto;
import br.com.senaibrasilia.projetofinal.util.JPAUtil;

public class ProdutoDAO {

	EntityManager em;

	public void cadastrar(Produto produto) {

		em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		em.persist(produto);
		em.getTransaction().commit();
		em.close();
	}

	public void atualizar(Produto produto) {
		
		em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		em.merge(produto);
		em.getTransaction().commit();
		em.close();
	}

	public void buscaPorId(Long id) {
		
		em = new JPAUtil().getEntityManager();
		Produto produto = null;
		produto = em.find(Produto.class, id);
		em.close();		
	}
	
	public void pesquisarPorNome(Long id, String nome) {
		
		em = new JPAUtil().getEntityManager();
		Produto produto = null;
		produto = em.find(Produto.class, id);
		em.close();
	}
	
	public List<Produto> pesquisarTodos() {
		
		
		em = new JPAUtil().getEntityManager();		
		Query query = (Query) em.createQuery("SELECT p FROM Produto p");		
		return ((javax.persistence.Query) query).getResultList();
	}
	
	public void remover(Long id) {

		em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		Produto produto = em.find(Produto.class, id);
		em.remove(produto);
		em.getTransaction().commit();
		em.close();		
	}


	
}
