package br.com.senaibrasilia.projetofinal.model;

import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name ="produtos")
public class Produto {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String nome, descri�ao;
	private BigDecimal pre�o;

	@ManyToOne(targetEntity = Categoria.class)
	private Categoria categoria;

	public Produto() {

		super();
	}

	public Produto(String nome, String descri�ao, BigDecimal pre�o, Categoria categoria) {
		super();
		this.nome = nome;
		this.pre�o = pre�o;
		this.descri�ao = descri�ao;
		this.categoria = categoria;
	}

	public long getID() {
		return id;
	}

	public void setID(long iD) {
		id = iD;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescri�ao() {
		return descri�ao;
	}

	public void setDescri�ao(String descri�ao) {
		this.descri�ao = descri�ao;
	}

	public BigDecimal getPre�o() {
		return pre�o;
	}

	public void setPre�o(BigDecimal pre�o) {
		this.pre�o = pre�o;
	}

	public Categoria getCategoria() {
		return categoria;
	}
}
