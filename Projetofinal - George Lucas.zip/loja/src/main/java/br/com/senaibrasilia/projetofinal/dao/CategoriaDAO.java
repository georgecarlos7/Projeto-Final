package br.com.senaibrasilia.projetofinal.dao;

import javax.persistence.EntityManager;

import br.com.senaibrasilia.projetofinal.model.Categoria;
import br.com.senaibrasilia.projetofinal.util.JPAUtil;

public class CategoriaDAO {

    private EntityManager em;

	public CategoriaDAO(EntityManager em) {
		super();
		this.em = em;		
	}

	public void cadastrar(Categoria categoria) {
		
		em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		em.persist(categoria);
		em.getTransaction().commit();
		em.close();
	}

	public void atualizar(Categoria categoria) {

		em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		em.merge(categoria);
		em.getTransaction().commit();
		em.close();		
	}

	public void remover(Long id) {
		
		em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		Categoria categoria = em.find(Categoria.class, id);
		em.remove(categoria);
		em.getTransaction().commit();
		em.close();
	}
}